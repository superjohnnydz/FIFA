# FIFA: Making Fairness More Generalizable in Classifiers Trained on Imbalanced Data

## Reproducing Experiments

### (Optional) Sweeps

All experiments are done using ``wandb`` sweeps. The sweep configs are
stored in ``./sweep_configs/`` with self-explanatory filenames.

### Reproducing Figures and Tables

The results of those sweeps are stored in the ``csv`` files in ``./csv_data``.
Please see the notebook ``reproduction.ipynb`` for details.