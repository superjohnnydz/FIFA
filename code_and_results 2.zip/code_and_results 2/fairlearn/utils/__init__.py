# Copyright (c) Fairlearn contributors.
# Licensed under the MIT License.

"""This module contains utilities for Fairlearn."""
