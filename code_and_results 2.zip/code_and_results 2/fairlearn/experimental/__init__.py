# Copyright (c) Fairlearn contributors.
# Licensed under the MIT License.
"""
Enables experimental functionality that may be migrated to other modules at a later point.

Warning:
    Anything can break from version to version without further warning.
"""
